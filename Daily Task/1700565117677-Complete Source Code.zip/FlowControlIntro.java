package FlowControlStatements;

public class FlowControlIntro {

    public static void main(String[] args) {
        //2 int a and b : a > b then print message a is > than b. else print msg b is greater than a
        int a =  100;
        int b = 70;
        int c = 500;
        // if a is greater than b print some message

        if((a > b) || (c < b)){  //
            System.out.println("Will this line get executed? ");
        }

        /*if((a > b) && (c < b)){  //
            System.out.println("Will this line get executed? ");
        }*/

        /*if(a > b){
            System.out.println("dummy message");  //
        }*/

        /*System.out.println("a is greater than b");
        System.out.println("b is greater than a");*/

        //ATM => if entered correct pin let user withdraw money
        // else show message saying please enter correct pin.

        boolean isItGoingToRainToday = true;

        if(isItGoingToRainToday){
            System.out.println("Carry umbrella or raincoat");
        }

    }
}
