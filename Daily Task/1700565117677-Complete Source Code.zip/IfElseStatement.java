package FlowControlStatements;

public class IfElseStatement {

    public static void main(String[] args) {
        int a = 1000;
        int b = 200;
        //2 int a and b : a > b then print message a is > than b. else print msg b is greater than a
        if(a > b){
            System.out.println("a is greater than b");
        } else {
            System.out.println("b is greater than a");
        }
    }
}
